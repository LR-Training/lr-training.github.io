require_relative '../../lib/data-generator.rb'
